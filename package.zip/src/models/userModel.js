const mysql = require('mysql');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '23062021',
    database: 'db_clinica'
});

db.connect((err) => {
    if (err) {
        console.error('Error al conectar a MySQL:', err);
    } else {
        console.log('Conectado a MySQL');
    }
});

module.exports = {
    findUser: (username, password, callback) => {
        db.query(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            [username, password],
            (err, results) => {
                if (err) {
                    console.error('Error en la consulta:', err);
                    callback(err, null);
                    return;
                }

                if (results.length > 0) {
                    // Usuario encontrado
                    callback(null, results[0]); // solo el primer resultado
                } else {
                    // Usuario no encontrado
                    callback(null, null);
                }
            }
        );
    }
};