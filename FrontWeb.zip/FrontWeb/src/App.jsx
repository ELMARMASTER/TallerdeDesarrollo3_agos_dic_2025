import { useState, useEffect } from "react";
import FormularioAlumno from "./components/FormularioAlumno";
import "./App.css";

function App() {
  const [alumnos, setAlumnos] = useState([]);
  const [alumnoEditando, setAlumnoEditando] = useState(null);
  const [error, setError] = useState("");
  const [resetForm, setResetForm] = useState(false); // Nuevo estado para resetear formulario

  useEffect(() => {
    const alumnosGuardados = JSON.parse(localStorage.getItem("alumnos")) || [];
    setAlumnos(alumnosGuardados);
  }, []);

  const guardarAlumnos = (nuevosAlumnos) => {
    setAlumnos(nuevosAlumnos);
    localStorage.setItem("alumnos", JSON.stringify(nuevosAlumnos));
  };

  const alumnoExiste = (alumno) => {
    return alumnos.some(a => 
      a.email_alumno.toLowerCase() === alumno.email_alumno.toLowerCase()
    );
  };

  const agregarAlumno = (alumno) => {
    // Si estamos editando, permitimos guardar sin validación de duplicado
    if (alumnoEditando) {
      let nuevosAlumnos;
      nuevosAlumnos = alumnos.map((a, i) =>
        i === alumnoEditando.index ? alumno : a
      );
      setAlumnoEditando(null);
      setError("");
      guardarAlumnos(nuevosAlumnos);
      return;
    }

    // Si no estamos editando, verificamos duplicados
    if (alumnoExiste(alumno)) {
      setError("❌ Este alumno ya está registrado (mismo email)");
      return;
    }

    // Si no existe, agregamos
    const nuevosAlumnos = [...alumnos, alumno];
    setError("");
    guardarAlumnos(nuevosAlumnos);
    
    // Activar el reset del formulario
    setResetForm(true);
  };

  const eliminarAlumno = (index) => {
    const nuevosAlumnos = alumnos.filter((_, i) => i !== index);
    guardarAlumnos(nuevosAlumnos);
    setError("");
  };

  const editarAlumno = (index) => {
    setAlumnoEditando({ ...alumnos[index], index });
    setError("");
    setResetForm(false); // Asegurarse de que no se resetee cuando editamos
  };

  return (
    <div className="app-container">
      <div className="main-layout">
        
        {/* FORMULARIO - IZQUIERDA */}
        <div className="form-container">
          <FormularioAlumno 
            agregarAlumno={agregarAlumno} 
            alumnoEditando={alumnoEditando}
            error={error}
            setError={setError}
            resetForm={resetForm}
            setResetForm={setResetForm}
          />
        </div>

        {/* LISTA DE ALUMNOS - DERECHA */}
        <div className="students-container">
          <div className="students-header">
            <h2>📋 Lista de Estudiantes</h2>
            <span className="students-count">{alumnos.length} alumnos</span>
          </div>

          {alumnos.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">👨‍🎓</div>
              <h4>No hay alumnos registrados</h4>
              <p>Agrega el primer estudiante</p>
            </div>
          ) : (
            <div className="students-list">
              {alumnos.map((alumno, index) => (
                <div key={index} className="student-item">
                  <div className="student-main-info">
                    <h5>{alumno.nombre_alumno}</h5>
                    <p className="student-email">{alumno.email_alumno}</p>
                    <div className="student-details">
                      <span className="badge course">{alumno.curso_alumno}</span>
                      <span className="badge gender">{alumno.sexo_alumno}</span>
                      <span className={`badge english ${alumno.habla_ingles ? 'yes' : 'no'}`}>
                        {alumno.habla_ingles ? "🗣️ Inglés: Sí" : "❌ Inglés: No"}
                      </span>
                    </div>
                  </div>
                  <div className="student-actions">
                    <button
                      className="btn-action edit"
                      onClick={() => editarAlumno(index)}
                      title="Editar alumno"
                    >
                      ✏️
                    </button>
                    <button
                      className="btn-action delete"
                      onClick={() => eliminarAlumno(index)}
                      title="Eliminar alumno"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;