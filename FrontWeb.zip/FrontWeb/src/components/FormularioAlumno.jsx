import { useState, useEffect } from "react";

const FormularioAlumno = ({ 
  agregarAlumno, 
  alumnoEditando, 
  error, 
  setError,
  resetForm,
  setResetForm 
}) => {
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [curso, setCurso] = useState("");
  const [sexo, setSexo] = useState("masculino");
  const [hablaIngles, setHablaIngles] = useState(false);

  // Efecto para cargar datos cuando se edita o resetear cuando se registra
  useEffect(() => {
    if (alumnoEditando) {
      setNombre(alumnoEditando.nombre_alumno);
      setEmail(alumnoEditando.email_alumno);
      setCurso(alumnoEditando.curso_alumno);
      setSexo(alumnoEditando.sexo_alumno);
      setHablaIngles(alumnoEditando.habla_ingles);
    } else {
      // Resetear campos cuando no hay edición
      setNombre("");
      setEmail("");
      setCurso("");
      setSexo("masculino");
      setHablaIngles(false);
    }
    setError("");
  }, [alumnoEditando, setError]);

  // Efecto para resetear el formulario cuando se registra un alumno exitosamente
  useEffect(() => {
    if (resetForm) {
      setNombre("");
      setEmail("");
      setCurso("");
      setSexo("masculino");
      setHablaIngles(false);
      setError("");
      setResetForm(false); // Resetear el flag
    }
  }, [resetForm, setResetForm, setError]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(""); // Limpiar error previo al enviar
    
    agregarAlumno({
      nombre_alumno: nombre,
      email_alumno: email,
      curso_alumno: curso,
      sexo_alumno: sexo,
      habla_ingles: hablaIngles,
    });
  };

  return (
    <div className="modern-form-container">
      <div className="form-header">
        <h2>{alumnoEditando ? "✏️ Editar Alumno" : "👨‍🎓 Nuevo Alumno"}</h2>
        <p>{alumnoEditando ? "Modifica los datos del estudiante" : "Registra un nuevo estudiante"}</p>
      </div>

      {/* Mostrar mensaje de error */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="modern-form">
        {/* Nombre */}
        <div className="form-group">
          <label className="form-label">Nombre completo</label>
          <input
            type="text"
            className="form-input"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            required
            placeholder="Juan Pérez García"
            style={{ color: '#000000' }}
          />
        </div>

        {/* Email */}
        <div className="form-group">
          <label className="form-label">Correo electrónico</label>
          <input
            type="email"
            className="form-input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            placeholder="ejemplo@correo.com"
            style={{ color: '#000000' }}
          />
        </div>

        {/* Curso */}
        <div className="form-group">
          <label className="form-label">Curso</label>
          <select
            className="form-select"
            value={curso}
            onChange={(e) => setCurso(e.target.value)}
            required
            style={{ color: '#000000' }}
          >
            <option value="">Selecciona un curso</option>
            <option value="ReactJS">🚀 ReactJS</option>
            <option value="Python">🐍 Python</option>
            <option value="NodeJS">💚 NodeJS</option>
            <option value="JavaScript">🟨 JavaScript</option>
          </select>
        </div>

        {/* Sexo */}
        <div className="form-group">
          <label className="form-label">Género</label>
          <div className="radio-group">
            <label className="radio-option">
              <input
                type="radio"
                value="masculino"
                checked={sexo === "masculino"}
                onChange={(e) => setSexo(e.target.value)}
              />
              <span className="radio-custom"></span>
              Masculino
            </label>
            <label className="radio-option">
              <input
                type="radio"
                value="femenino"
                checked={sexo === "femenino"}
                onChange={(e) => setSexo(e.target.value)}
              />
              <span className="radio-custom"></span>
              Femenino
            </label>
          </div>
        </div>

        {/* Inglés */}
        <div className="form-group">
          <label className="form-label">¿Habla inglés?</label>
          <div className="switch-container">
            <label className="switch">
              <input
                type="checkbox"
                checked={hablaIngles}
                onChange={(e) => setHablaIngles(e.target.checked)}
              />
              <span className="slider"></span>
            </label>
            <span className="switch-label">
              {hablaIngles ? "✅ Sí habla inglés" : "❌ No habla inglés"}
            </span>
          </div>
        </div>

        {/* Botón */}
        <button
          type="submit"
          className={`submit-btn ${alumnoEditando ? 'edit' : 'create'}`}
        >
          {alumnoEditando ? "💾 Guardar cambios" : "✅ Registrar alumno"}
        </button>
      </form>
    </div>
  );
};

export default FormularioAlumno;