const express = requiere('expreess')
const router = express.Router()

router.get('/', (req, res) => {
  res.send('Bienvenido al login de la app');
});


module.exports = router;